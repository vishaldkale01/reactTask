import React from 'react'

export default function Product() {
  return (
    <div>product</div>
  )
}
